package io.testinium.constant;

public class ConstantsMainPage {
}
